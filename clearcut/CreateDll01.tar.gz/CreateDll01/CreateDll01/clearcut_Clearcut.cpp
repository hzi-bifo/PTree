#include "jni.h"
#include <stdio.h>
#include <stdlib.h>
#include "clearcut_Clearcut.h"
#include "clearcut_nj.h"


void unallocate_output_matrix(jfloat ** matrix);

/** 
 * JNI interface implementation.
 * input: fasta file, list of arguments, arguments` count
 * output: linearized NJ tree (described in: nj_tree.cpp)
 * */
JNIEXPORT jobjectArray JNICALL Java_clearcut_Clearcut_clearcutMain
  (JNIEnv *env, jobject obj, jstring jfasta_file, jstring jarg, jint jarg_count){
	

	/* get an input fasta file */	
	const char * fasta_file = (*env).GetStringUTFChars(jfasta_file, NULL);
	if (fasta_file == NULL) {
		printf("clearcut: Failed to get fasta string.. (OutOfMemoryError)");
		return NULL; 
	}

	/* get arguments */	
	const char * arg = (*env).GetStringUTFChars(jarg, NULL);
	if (arg == NULL) {
		printf("clearcut: Failed to get arguments.. (OutOfMemoryError)");
		return NULL; 
	}

	/* get argument count */
	int arg_count = (int)jarg_count;

	/* print input data */
	//printf("Hello World Clearcut!\n");
	//printf("Fasta file: %s\n",fasta_file);
	//printf("Arguments %s\n", arg);
	//printf("Arg count: %d\n",arg_count);

	/* call the clearcut interface method */
	jfloat ** output_matrix = clearcut_NJ((char *)fasta_file, (char *)arg, arg_count);

	/* release resources from input arguments */
	(*env).ReleaseStringUTFChars(jfasta_file, fasta_file);
	(*env).ReleaseStringUTFChars(jarg, arg);

	if (output_matrix == NULL){
		printf("clearcut: Error, null matrix returned..");
		return NULL;
	}

	if ((output_matrix[0] == NULL)||(output_matrix[1] == NULL)||(output_matrix[2] == NULL)||(output_matrix[3] == NULL)){
		printf("clearcut: Error, matrix has a wrong shape");
	}
	
	/* output printing */
	/*if (output_matrix != NULL){
		int len = (int)output_matrix[3][0];
		printf("edges count: %d\n", len);
		for (int i=0; i<len; i++){
			printf("edge: (%f,%f):%f\n", output_matrix[0][i], output_matrix[1][i], output_matrix[2][i]);
		}
	}*/

	int length = output_matrix[3][0];
	int height = 4;

	/* create the output matrix */
	jobjectArray result;
	jclass floatArrCls = (*env).FindClass("[F");
	if (floatArrCls == NULL) {
		unallocate_output_matrix(output_matrix);
		printf("clearcut: Error, unable to allocate floatArrCls");
		return NULL; // exception thrown  
	}
	result = (*env).NewObjectArray(height, floatArrCls, NULL);
	if (result == NULL) {
		unallocate_output_matrix(output_matrix);
		printf("clearcut: Error, unable to allocate NewObjectArray... (OutOfMemoryError)");
		return NULL; // out of memory error thrown  
	}

	int size;
	for (int i=0; i<height; i++){
		size = (i<3)?length:1;
		jfloatArray farr = (*env).NewFloatArray(size);
		if (farr == NULL) {
			unallocate_output_matrix(output_matrix);
			printf("clearcut: Error, unable to allocate NewFloatArray... (OutOfMemoryError)");
			return NULL; // out of memory error thrown 
		}
		
		(*env).SetFloatArrayRegion(farr, 0, size, output_matrix[i]);
		(*env).SetObjectArrayElement(result, i, farr);
		(*env).DeleteLocalRef(farr);
	}

	unallocate_output_matrix(output_matrix);

	return result;
}


void unallocate_output_matrix(jfloat ** matrix){
	for (int i=0; i<4; i++){
		free(matrix[i]);
	}
	free(matrix);
}