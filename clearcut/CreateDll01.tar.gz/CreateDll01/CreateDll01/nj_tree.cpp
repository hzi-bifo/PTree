
#include "nj_tree.h"
#include <stdlib.h>
#include <stdio.h>


int count_nodes(NJ_TREE *tree);
void tree_to_edges(NJ_TREE *tree, DMAT *dmat, jfloat *v1, jfloat *v2, jfloat *d, int *edge_index, int *internal_node_name_gen, jfloat root_name);

/**
 * Encode a tree to the matrix.
 *
 * leaf vertices have names: 0,1,2,3..
 * internal vertices have names: -2,-3, ..
 * unvalid name of a vertex is: -1
 *
 * @return the first array is an array of vertices` names
 *             second also (represents an edge)
 *         the third edges` length
 *         the fourth the length of the array (number of edges)
 *
 */
jfloat ** get_linearized_nj_tree(NJ_TREE *tree, DMAT *dmat){

	/* number of nodes in a tree */
	int node_count = count_nodes(tree);
	int edge_count = node_count - 1;
    
	/* allocate output arrays 
	 *
	 * one edge (v1,v2) has a length "d"
	 */
	jfloat **edges = (jfloat **)malloc(sizeof(jfloat *)*4);
	jfloat * v1 = (jfloat *)malloc(sizeof(jfloat)*edge_count);
	jfloat * v2 = (jfloat *)malloc(sizeof(jfloat)*edge_count);
	jfloat * d = (jfloat *)malloc(sizeof(jfloat)*edge_count);
	jfloat * len = (jfloat *)malloc(sizeof(jfloat)*1);
	if ((v1 == NULL) || (v2 == NULL) || (d == NULL) || (edges == NULL) || (len == NULL)){
		printf("out of memory..");
		return NULL;
	}

	edges[0] = v1;
	edges[1] = v2;
	edges[2] = d;
	edges[3] = len;

	int edge_index = -1;//the index of the last edge in an array
	int internal_node_name_gen = -2;

	for (int i=0; i<edge_count; i++){
		v1[i] = -1.0;
		v2[i] = -1.0;
		d[i] = -1.0;
	}

	/* transform a tree to edges */
	tree_to_edges(tree, dmat, v1, v2, d, &edge_index, &internal_node_name_gen, (jfloat)internal_node_name_gen);

	/* number of edges in an array */
	len[0] = (jfloat)(edge_index + 1);

	if ((edge_index + 1) != edge_count){
		printf("tree linearization: weird edge count!");
		return NULL;
	}

	return edges;
}


/**
 * Transforms a tree to the list of edges.
 *
 * @param tree - NJ tree
 * @param dmat - distance matrix to get leaf nodes` names
 * @param v1 - one vertex of an edge
 * @param v2 - second vertex of an edge
 * @param d - the length of an edge
 * @param edge_index - an index of the last edge in arrays
 * @param internal_node_name_gen variable to generate unique internal nodes names
 * @param root_name the name of the root of the tree
 * */
void tree_to_edges(NJ_TREE *tree, DMAT *dmat, jfloat *v1, jfloat *v2, jfloat *d, int *edge_index, int *internal_node_name_gen, jfloat root_name){

	if ((tree == NULL) || (tree->taxa_index != NJ_INTERNAL_NODE)){
		return;
	} else {

		/* for each internal node store both its edges */
		jfloat name_left = -1.0;
		jfloat name_right = -1.0;

		/* get left node`s name */
		if (tree->left != NULL){
			if (tree->left->taxa_index != NJ_INTERNAL_NODE){
				/* a node has a name */
				name_left = (jfloat)atof(dmat->taxaname[tree->left->taxa_index] + 1);// + 1 since we skip the first character!!!!!!!!!
			} else {
				/* I have to make up the node`s name */
				(*internal_node_name_gen)--;
				name_left = (jfloat)(*internal_node_name_gen);
			}
		} else {
			printf("error: left branche is null.. (1)");
		}

		/* store left edge */
		if (tree->left != NULL){
		
			int idx = ++(*edge_index);
			
			v1[idx] = root_name;
			v2[idx] = name_left;
			d[idx] = (jfloat)tree->left->dist;
			//printf("D: %f\n",tree->left->dist);
		
		} else {
			printf("error: left branche is null..");
		}

		/* store edges in the left subtree */
		tree_to_edges(tree->left, dmat, v1, v2, d, edge_index, internal_node_name_gen, name_left);

		/* get right node`s name */
		if (tree->right != NULL){
			if (tree->right->taxa_index != NJ_INTERNAL_NODE){
				/* a node has a name */
				name_right = (jfloat)atof(dmat->taxaname[tree->right->taxa_index] + 1);// + 1 since we skip the first character!!!!!!!!!
			} else {
				/* I have to make up the node`s name */
				(*internal_node_name_gen)--;
				name_right = (jfloat)(*internal_node_name_gen);
			}
		} else {
			printf("error: right branche is null.. (2)");
		}

		/* store right edge */
		if (tree->right != NULL){
		
			int idx = ++(*edge_index);
			
			v1[idx] = root_name;
			v2[idx] = name_right;
			d[idx] = (jfloat)tree->right->dist;
			//printf("D: %f\n",tree->right->dist);
		
		} else {
			printf("error: right branche is null..");
		}

		/* store edges in the right subtree */
		tree_to_edges(tree->right, dmat, v1, v2, d, edge_index, internal_node_name_gen, name_right);
	}
}



/** 
 * Count the number of nodes.
 **/
int count_nodes(NJ_TREE *tree){

	if (tree == NULL){
		return 0;
	} else {
		if (tree->taxa_index != NJ_INTERNAL_NODE){
			return 1;
		} else {
			return 1 + count_nodes(tree->left) + count_nodes(tree->right);
		}
	}

}