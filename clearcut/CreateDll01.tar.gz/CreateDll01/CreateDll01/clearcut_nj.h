
#ifndef _INC_CLEARCUT_NJ_H_
#define _INC_CLEARCUT_NJ_H_ 1

#include <jni.h>

/* parse arguments and call the main method */
jfloat ** clearcut_NJ(char * fasta_file, char * arg, int arg_count);

char * to_string(char * str);

#endif /* _INC_CLEARCUT_NJ_H_ */