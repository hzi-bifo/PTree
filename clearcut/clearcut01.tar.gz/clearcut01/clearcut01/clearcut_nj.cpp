#include "clearcut_nj.h"
#include "clearcut.h"

#include <stdlib.h>
#include <string.h>

/**
 * Parse arguments and call method clearcut_main2 from clearcut_main.h
 *
 */
jfloat ** clearcut_NJ(char * fasta_file, char * arg, int arg_count){
	
	char ** argv = (char **)malloc(sizeof(char*)*arg_count);

	/* parse arguments */
	if (arg != NULL){

		int idx_start = 0;
		int idx_end = 0;
		for (int i=0; i<arg_count; i++){
			
			while ((arg[idx_end] != '\0') && (arg[idx_end] != ' ')){
				idx_end++;
			}

			arg[idx_end] = '\0';
			argv[i] = to_string(arg + idx_start);
			idx_start = ++idx_end;
			idx_end++;
		}

	} else {
		return NULL;
	}
	
	/* call main */
	jfloat ** output_matrix = clearcut_main2(arg_count, argv, fasta_file);
	
	/* free memory */
	for (int i=0; i<arg_count; i++){
		free(argv[i]);
	}
	free(argv);

	return output_matrix;
}


char * to_string(char * str){
	char * ret = (char *)malloc(strlen(str) + 1);
	strcpy(ret,str);
	return ret;
}