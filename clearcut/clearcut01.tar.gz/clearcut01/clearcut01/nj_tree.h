#ifndef _NJ_MATRIX_H_
#define _NJ_MATRIX_H_ 1

#include <jni.h>

#include "clearcut.h"

jfloat ** get_linearized_nj_tree(NJ_TREE *tree, DMAT *dmat);


#endif /* _NJ_MATRIX_H_ */