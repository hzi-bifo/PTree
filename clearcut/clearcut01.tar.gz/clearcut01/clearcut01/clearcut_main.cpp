// clearcut01.cpp : Defines the entry point for the console application.
//

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <jni.h>

#include "stdafx.h"

#include "clearcut_nj.h"



int _tmain(int argc, _TCHAR* argv[]){
	
	/* set argument count */
	int arg_count = 5;
	//int arg_count = 4;

	/* set arguments */
	char * arg = to_string("clearcut01.exe --in=C:\\Users\\Ivan\\Documents\\A_SAAR\\HIWI\\circuit\\visual_studio\\clearcut01\\clearcut01\\examples\\alignment1.dist --out=output.txt -a -D");
	//char * arg = to_string("clearcut01.exe --in=C:\\Users\\Ivan\\Documents\\A_SAAR\\HIWI\\circuit\\visual_studio\\clearcut01\\clearcut01\\examples\\alignment1.dist --out=output.txt -d");
	
	/* set fasta file */
	char * fasta_file = to_string("> s0\nGGCCAGCAAC\n> s1\nTGCCAATAGT\n> s2\nGGGGAATAGT\n> s3\nAATCGACGGT");
	//char * fasta_file = to_string("4 \n s0 \n s1 5.0 \n s2 6.0 3.0 \n s3 8.0 6.0 7.0 \n");

	/* call clearcut */
	jfloat ** output_matrix = clearcut_NJ(fasta_file, arg, arg_count);

	if (output_matrix != NULL){

		int len = (int)output_matrix[3][0];

		printf("edges count: %d\n", len);
			
		for (int i=0; i<len; i++){
			printf("edge: (%f,%f):%f\n", output_matrix[0][i], output_matrix[1][i], output_matrix[2][i]);
		}
	
	}
	getchar();
	return 0;
}

